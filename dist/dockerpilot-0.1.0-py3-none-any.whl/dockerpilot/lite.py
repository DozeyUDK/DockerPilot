def main():
    print("DockerPilot lite version running...")
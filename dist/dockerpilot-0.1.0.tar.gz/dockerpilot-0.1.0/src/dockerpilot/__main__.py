# dockerpilot/__main__.py
from .main import main  # importuje funkcję main z dockerpilot/main.py

if __name__ == "__main__":
    main()  # uruchamia main przy wywołaniu python -m dockerpilot

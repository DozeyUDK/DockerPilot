# Docker Pilot - User Guide

Docker container management tool with advanced deployment capabilities, real-time monitoring, and CI/CD integration.

## Versions

This project includes two versions:

### Docker Pilot (Full Version) - `dockerpilot.py`
The complete feature-rich version with:
- Advanced deployment strategies (Rolling, Blue-Green, Canary)
- CI/CD pipeline generation
- Environment promotion
- Integration testing framework
- Monitoring and alerting
- Backup and restore functionality

**Recommended for:** Production environments, DevOps workflows, teams needing advanced deployment features

### Docker Pilot Lite - `dockerpilot-lite.py`
A lightweight version focusing on core container management:
- Basic container operations (start, stop, restart, remove)
- Image management
- Container monitoring
- Simpler interface with fewer dependencies

**Recommended for:** Development environments, quick container management, learning Docker basics, systems with limited resources

---

## Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Container Management](#container-management)
- [Image Management](#image-management)
- [Monitoring](#monitoring)
- [Deployment Strategies](#deployment-strategies)
- [CI/CD Integration](#cicd-integration)
- [Configuration](#configuration)
- [Advanced Features](#advanced-features)
- [Troubleshooting](#troubleshooting)

## Features

### Core Capabilities (Both Versions)
- **Container Operations**: Start, stop, restart, remove, pause, unpause containers
- **Image Management**: List, build, and remove Docker images
- **Real-time Monitoring**: CPU, memory, network I/O, and process tracking
- **Health Checks**: Automated container health validation
- **Interactive Dashboard**: Live metrics with trend indicators

### Advanced Deployment (Full Version Only)
- **Rolling Deployment**: Zero-downtime updates with automatic rollback
- **Blue-Green Deployment**: Parallel environment switching for maximum safety
- **Canary Deployment**: Gradual traffic shifting with performance monitoring

### DevOps Integration (Full Version Only)
- GitHub Actions, GitLab CI, and Jenkins pipeline generation
- Environment promotion (dev → staging → prod)
- Integration testing framework
- Monitoring and alerting system
- Backup and restore functionality

## Installation

### Prerequisites
- Python 3.8 or higher
- Docker Engine 20.10+
- Docker daemon running and accessible

### Install Dependencies

**For Docker Pilot (Full Version):**
```bash
pip install docker pyyaml requests rich
```

**For Docker Pilot Lite:**
```bash
pip install docker rich
```

### Optional Dependencies

```bash
# For Git integration (Full version)
pip install GitPython

# For testing
pip install pytest pytest-cov
```

### Verify Installation

```bash
python dockerpilot.py validate
```

## Quick Start

### Interactive Mode

Run without arguments to enter interactive mode:

```bash
python dockerpilot.py
```

Or for the lite version:

```bash
python dockerpilot-lite.py
```

Select from available commands:
- `list` - List all containers
- `start` - Start a container
- `stop` - Stop a container
- `monitor` - Real-time monitoring
- `deploy-init` - Create deployment config (Full version only)
- And many more...

### CLI Mode with Alias

To avoid typing the full path every time, you can set up an alias or add the script to your system path.

#### Linux / macOS (Bash/Zsh)

1. Open your shell configuration file (`~/.bashrc` or `~/.zshrc`):
```bash
nano ~/.bashrc
```

2. Add an alias pointing to your Docker Pilot script:
```bash
# Full version
alias dockerpilot='python3 /full/path/to/dockerpilot.py'

# Lite version
alias dockerpilot-lite='python3 /full/path/to/dockerpilot-lite.py'
```
> Replace `/full/path/to/` with the actual path to your Docker Pilot directory.

3. Apply the changes:
```bash
source ~/.bashrc
```

4. Now you can run Docker Pilot from any directory:
```bash
dockerpilot list --all
dockerpilot monitor myapp --duration 300
```

---

#### Windows (PowerShell)

1. Open PowerShell and check your profile:
```powershell
echo $PROFILE
```

2. If the file does not exist, create it:
```powershell
New-Item -Type File -Path $PROFILE -Force
```

3. Edit your profile:
```powershell
notepad $PROFILE
```

4. Add a function to create a local alias:
```powershell
# Full version
function dockerpilot { python "C:\Users\YourUsername\DockerPilot\dockerpilot.py" @args }

# Lite version
function dockerpilot-lite { python "C:\Users\YourUsername\DockerPilot\dockerpilot-lite.py" @args }
```
> Replace `C:\Users\YourUsername\DockerPilot\` with your actual path.

5. Save and close Notepad, then reload your profile:
```powershell
. $PROFILE
```

6. You can now run Docker Pilot from any location in PowerShell:
```powershell
dockerpilot list --all
dockerpilot monitor myapp --duration 300
```

### CLI Mode

Use specific commands directly:

```bash
# List all containers
python dockerpilot.py container list --all

# Monitor containers
python dockerpilot.py monitor myapp --duration 300

# Deploy application (Full version only)
python dockerpilot.py deploy config deployment.yml --type rolling
```

## Container Management

### List Containers

```bash
# Table format (default)
python dockerpilot.py container list --all

# JSON format
python dockerpilot.py container list --format json
```

### Container Operations

```bash
# Start container
python dockerpilot.py container start myapp

# Stop container (with timeout)
python dockerpilot.py container stop myapp --timeout 30

# Restart container
python dockerpilot.py container restart myapp

# Remove container
python dockerpilot.py container remove myapp --force

# Pause/Unpause
python dockerpilot.py container pause myapp
python dockerpilot.py container unpause myapp
```

### View Container Logs

Interactive mode:
```bash
python dockerpilot.py
# Choose: logs
```

### View Container Details (JSON)

Interactive mode:
```bash
python dockerpilot.py
# Choose: json
# Enter container name
```

## Image Management

### List Images

```bash
# Table format
python dockerpilot.py container list-images --all

# JSON format
python dockerpilot.py container list-images --format json
```

### Build Images

```bash
python dockerpilot.py build /path/to/dockerfile myapp:latest --no-cache
```

Interactive mode:
```bash
python dockerpilot.py
# Choose: build
# Follow prompts
```

### Remove Images

```bash
python dockerpilot.py container remove-image myapp:latest --force
```

## Monitoring

### Real-time Dashboard

Monitor all running containers:
```bash
python dockerpilot.py monitor --duration 300
```

Monitor specific containers:
```bash
python dockerpilot.py monitor webapp database cache --duration 600
```

The dashboard displays:
- Container status
- CPU usage with trend indicators (↗️ ↘️ →)
- Memory usage and percentage
- Network I/O (download/upload)
- Process count (PIDs)
- Uptime

Metrics are automatically saved to `docker_metrics.json`.

## Deployment Strategies

> **Note:** Advanced deployment strategies are only available in the full version (`dockerpilot.py`)

### 1. Create Deployment Configuration

```bash
python dockerpilot.py deploy init --output deployment.yml
```

Edit `deployment.yml`:

```yaml
deployment:
  image_tag: 'myapp:latest'
  container_name: 'myapp'
  port_mapping:
    '8080': '8080'
  environment:
    ENV: 'production'
    DEBUG: 'false'
  volumes:
    './data': '/app/data'
  restart_policy: 'unless-stopped'
  health_check_endpoint: '/health'
  health_check_timeout: 30
  health_check_retries: 10
  cpu_limit: '1.0'
  memory_limit: '1g'

build:
  dockerfile_path: '.'
  context: '.'
  no_cache: false
  pull: true
```

### 2. Rolling Deployment (Zero-Downtime)

```bash
python dockerpilot.py deploy config deployment.yml --type rolling
```

**Process:**
1. Builds new image
2. Creates new container with temporary name
3. Performs health checks
4. Switches traffic (stops old, renames new)
5. Automatic rollback on failure

### 3. Blue-Green Deployment (Safest)

```bash
python dockerpilot.py deploy config deployment.yml --type blue-green
```

**Process:**
1. Builds new image
2. Deploys to inactive slot (blue/green)
3. Runs parallel tests
4. Health checks on new deployment
5. Zero-downtime traffic switch
6. Keeps old version for instant rollback

### 4. Canary Deployment (Gradual Rollout)

```bash
python dockerpilot.py deploy config deployment.yml --type canary
```

**Process:**
1. Deploys canary version (5% traffic)
2. Monitors performance for 30 seconds
3. Validates error rates
4. Promotes to full deployment if successful
5. Automatic rollback if issues detected

### View Deployment History

```bash
python dockerpilot.py deploy history --limit 20
```

## CI/CD Integration

> **Note:** CI/CD features are only available in the full version (`dockerpilot.py`)

### Generate Pipeline Configurations

**GitHub Actions:**
```bash
python dockerpilot.py pipeline create --type github --output .github/workflows
```

**GitLab CI:**
```bash
python dockerpilot.py pipeline create --type gitlab
```

**Jenkins:**
```bash
python dockerpilot.py pipeline create --type jenkins
```

### Environment Promotion

Promote from dev to staging:
```bash
python dockerpilot.py promote dev staging --config deployment.yml
```

Promote to production:
```bash
python dockerpilot.py promote staging prod --config deployment.yml
```

**Features:**
- Environment-specific resource allocation
- Automated pre-promotion checks
- Post-promotion validation
- Rollback on failure

## Configuration

### Logging Levels

```bash
python dockerpilot.py --log-level DEBUG container list
```

Available levels: DEBUG, INFO, WARNING, ERROR

### Configuration Files

The tool uses several configuration files:

- `deployment.yml` - Deployment configuration (Full version)
- `alerts.yml` - Monitoring alerts (Full version)
- `integration-tests.yml` - Test definitions (Full version)
- `docker_pilot.log` - Application logs
- `docker_metrics.json` - Performance metrics
- `deployment_history.json` - Deployment records (Full version)

### Export/Import Configuration

```bash
# Export all configs (Full version)
python dockerpilot.py config export --output backup.tar.gz

# Import configs (Full version)
python dockerpilot.py config import backup.tar.gz
```

## Advanced Features

> **Note:** Advanced features are only available in the full version (`dockerpilot.py`)

### Integration Testing

Create test configuration (`integration-tests.yml`):

```yaml
tests:
  - name: 'Health Check'
    type: 'http'
    url: 'http://localhost:8080/health'
    expected_status: 200
    timeout: 5
  
  - name: 'API Endpoint'
    type: 'http'
    url: 'http://localhost:8080/api/status'
    expected_status: 200
    timeout: 10
```

Run tests:
```bash
python dockerpilot.py test --config integration-tests.yml
```

### Monitoring Alerts

Setup alerts:
```bash
python dockerpilot.py alerts --config alerts.yml
```

Configure alert rules in `alerts.yml`:

```yaml
alerts:
  - name: 'high_cpu_usage'
    condition: 'cpu_percent > 80'
    duration: '5m'
    severity: 'warning'
    message: 'CPU usage is above 80%'

notification_channels:
  - type: 'slack'
    webhook_url: 'https://hooks.slack.com/...'
    channel: '#alerts'
```

### Backup and Restore

Create backup:
```bash
python dockerpilot.py backup create --path ./backup_20240104
```

Restore from backup:
```bash
python dockerpilot.py backup restore ./backup_20240104
```

Backups include:
- Container configurations
- Image information
- Network settings
- Volume definitions

### Production Checklist

Generate deployment checklist:
```bash
python dockerpilot.py checklist --output production-checklist.md
```

### Documentation Generation

Generate complete documentation:
```bash
python dockerpilot.py docs --output ./docs
```

## Troubleshooting

### Common Issues

**Docker Connection Failed:**
```bash
# Check Docker status
docker info

# Add user to docker group
sudo usermod -aG docker $USER

# Restart Docker
sudo systemctl restart docker
```

**Permission Denied:**
```bash
sudo chown $USER:docker /var/run/docker.sock
sudo chmod 660 /var/run/docker.sock
```

**Health Check Failures:**
- Verify endpoint exists: `curl http://localhost:8080/health`
- Check container logs
- Increase timeout in deployment config

**Port Already in Use:**
```bash
# Find process using port
netstat -tulpn | grep :8080

# Kill process or use different port
```

### Debug Mode

Enable detailed logging:
```bash
python dockerpilot.py --log-level DEBUG <command>
```

### Log Files

Check logs for detailed information:
- `docker_pilot.log` - Main application log
- `docker_metrics.json` - Performance data
- `deployment_history.json` - Deployment records (Full version)
- `integration-test-report.json` - Test results (Full version)

## System Validation

Verify all requirements are met:

```bash
python dockerpilot.py validate
```

Checks:
- Python version (3.8+)
- Docker connectivity
- Required Python modules
- Disk space
- Docker daemon permissions

## Choosing Between Full and Lite Version

### Use Docker Pilot (Full Version) when you need:
- Production-grade deployments with zero downtime
- Advanced deployment strategies (Rolling, Blue-Green, Canary)
- CI/CD pipeline integration
- Environment promotion workflows
- Integration testing
- Monitoring alerts
- Backup and restore capabilities

### Use Docker Pilot Lite when you need:
- Quick container management during development
- Simple deployment scenarios
- Lower resource footprint
- Faster startup time
- Learning Docker basics
- Minimal dependencies

## Support

- **Issues**: Report bugs or request features via GitHub Issues
- **Documentation**: Check the `docs/` directory
- **Logs**: Review `docker_pilot.log` for detailed error messages

## Best Practices

1. **Always test deployments** in non-production environments first
2. **Use health checks** to ensure application readiness
3. **Set resource limits** to prevent resource exhaustion
4. **Enable monitoring alerts** for production deployments (Full version)
5. **Create backups** before major changes (Full version)
6. **Review deployment history** to track changes (Full version)
7. **Use blue-green deployments** for critical production updates (Full version)
8. **Test rollback procedures** regularly
9. **Start with Lite version** for learning, upgrade to Full version for production

## License

This tool is provided as-is for container management and deployment automation.

---

**Version**: Enhanced v3  
**Python**: 3.8+  
**Docker**: 20.10+  
**Available in**: Full (`dockerpilot.py`) and Lite (`dockerpilot-lite.py`) versions
